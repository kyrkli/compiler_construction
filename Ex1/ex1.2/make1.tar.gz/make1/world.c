void hello (void);

int main (void) {
    hello();
}
